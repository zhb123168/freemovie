# -*- coding: utf-8 -*-
__author__ = "Bob"

import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QListWidgetItem
import ui.mainwindow as uiMainWindow
import movie as zuidazy
import webbrowser
from urllib.parse import quote, urlparse
import requests

from PyQt5 import sip

def check_token():
    resp = requests.get("http://movie.ziyimingze.com/token")
    if "fdfasfasdferwerewr" in resp.text:
        return True
    return False
    pass

def search_button_click():

    if False == check_token():
        return

    input = ui.searchLineEdit.text()
    datas = zuidazy.zuidazy5(input)
    #设置总数
    ui.counterLabel.setText(str(len(datas)))
    ui.mainwidget.show()

    ui.playListWidget.clear()
    #填充列表
    for item in datas:
        # print(item)
        #{'url': 'http://anning.luanniao-zuida.com/1908/地球脉动第一季-01.mp4', 'id': '62059', 'name': '地球脉动第一季 11集全'}
        ui.playListWidget.addItem(item['url'])
    pass

def playList_doubleClicked():
    item = ui.playListWidget.currentItem()
    url = item.text()
    filename = url[url.rfind('/')+len('/'):]
    # print(filename)
    url = url.replace(filename, quote(filename, 'utf-8'))
    # print(url)
    url = "https://movie.ziyimingze.com/?id=" + url
    webbrowser.open(url)
    pass

if __name__ == '__main__':
    app = QApplication(sys.argv)
    MainWindow = QMainWindow()
    ui = uiMainWindow.Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()

    #添加信号函数
    ui.searchButton.clicked.connect(search_button_click)
    ui.playListWidget.doubleClicked.connect(playList_doubleClicked)

    #测试数据
    ui.searchLineEdit.setText('地球脉动')

    sys.exit(app.exec_())
